# https://jlcpcb.com/api/file/downloadByFileSystemAccessId/8588918861252583424

Read by Inky on 2026-11-16. Source: <https://jlcpcb.com/api/file/downloadByFileSystemAccessId/8588918861252583424>

---

{"code":203,"message":"Non-Authoritative Information"}
