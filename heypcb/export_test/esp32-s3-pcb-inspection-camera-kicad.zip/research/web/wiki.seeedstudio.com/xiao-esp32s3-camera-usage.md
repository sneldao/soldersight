# https://wiki.seeedstudio.com/xiao_esp32s3_camera_usage/

Read by Inky on 2026-11-16. Source: <https://wiki.seeedstudio.com/xiao_esp32s3_camera_usage/>

---

Camera Usage for Sense Version | Seeed Studio Wiki 

Skip to main content 
 Collaborate with Seeed - Creator , Ranger , or Contributor , there is always a role ideal for you! 

Quick Links Sensor and Sensing Networking Edge Computing Cloud 
 Explore with Topics TinyML SenseCraft Model Assistant Home Assistant Open Source Edge AI Wiki 矽递科技 (中文) Wiki SeeedStudio (日本語) Wiki SeeedStudio (Español) 
 FAQs NVIDIA Jetson Series Seeed Studio XIAO Series reComputer R1000 Series reTerminal reRouter Odyssey Wio Terminal Discord Email Forum Have Suggestions? 
 Get Involved Affiliate & Creator Rangers Contributors Apply for Rangers Direct to Assignments More about Rangers More about Contributors 

Bazaar 🛍️ AI Platform SenseCraft AI reComputer AI Lab 

Search 

Getting Started Weekly Wiki Sensing Grove 
 SenseCAP 
 SenseCAP Watcher 
 mmWave Radar Sensor 
 XIAO 
 Exhibition for XIAO Series XIAO SAMD21 Series 
 XIAO RA4M1 
 XIAO MG24 
 XIAO RP2040 Series 
 XIAO RP2350 
 XIAO nRF52840 Series 
 XIAO nRF54L15 Series 
 XIAO nRF54LM20A Series 
 XIAO ESP32C3 
 XIAO ESP32C5 
 XIAO ESP32C6 
 XIAO ESP32S3 Series 
 Getting Started with Seeed Studio XIAO ESP32-S3 Series Pin Multiplexing with Seeed Studio XIAO ESP32-S3 (Sense) XIAO ESP32S3 Sense Sleep Modes Wireless Connection 
 Programming Language 
 RTOS 
 Hardware Usage 
 Microphone Usage for Sense Version MicroSD card for Sense Version Camera Usage for Sense Version Applications 
 XIAO STM32C5 
 XIAO Debug Mate 
 Expansion Boards for XIAO 
 XIAO + ESP-IDF + ESP-Matter 
 ESP-NOW on XIAO ESP32 Series PCB Design for XIAO Kit with Courses 
 FAQs for XIAO Series XIAO Gadgets 
 ePaper Displays 
 LCD Displays 
 Wio Terminal 
 reSpeaker 
 Other Sensing Modules 
 Other Microcontrollers 
 Network Mesh Network 
 LoRa Wio Series 
 SenseCAP Gateway 
 SenseCAP K1100 
 SenseCAP LoRaWAN Starter Kit 
 Raspberry Pi Solutions 
 Rockchip Solutions 
 Other Network Devices 
 Edge Computing RK Devices 
 Raspberry Pi Devices 
 NVIDIA® Jetson™ ESP Devices 
 BeagleBone® 
 ODYSSEY 
 reCamera 
 Other Edge Devices 
 Robotics Page SenseCraft & Cloud SenseCraft AI 
 CodeCraft 
 SenseCraft APP 
 SenseCraft Data Platform 
 SenseCraft Seeedash 
 SenseCraft Robotics 
 Solutions Vision & Video AI 
 Acoustic & Audio AI 
 Home & Building Automation 
 Environmental Sensing 
 Indoor Positioning & Tracking 
 Off-Grid Communication 
 Fusion PCB & PCBA 
 Light Customization 
 One-Stop Services 
 PCBA Testing Solutions 
 Manufacturing Preparation 
 Technology Topics Home Assistant 
 TinyML 
 Open Source Edge AI Contributions Github Contributions Guide 
 Scale up Your Creation with Seeed Studio Fusion Popular Platforms Arduino 
 Raspberry Pi 
 Micro:bit 
 Discontinued Products Product List 
 About Seeed License 

XIAO XIAO ESP32S3 Series Hardware Usage Camera Usage for Sense Version On this page 

Camera Usage in Seeed Studio XIAO ESP32S3 Sense

tip
 The content of this tutorial is only applicable to Seeed Studio XIAO ESP32S3 Sense.

In this tutorial, we will walk you through using the camera module on the XIAO ESP32S3 Sense. This tutorial is divided into the following parts, first, we will explain the camera function provided by ESP32 and its functions. Secondly, we will bring you how to use the camera in two dimensions: taking pictures and recording videos, and finally, we will create some interesting projects around taking pictures and recording videos.

Seeed Studio XIAO ESP32S3 Sense 
 Get One Now 🖱️ 

Getting Started ​ 

This tutorial may involve the use of microSD card, camera, antenna, etc. Please prepare the following materials and install them correctly according to your project needs.

Installation of antenna ​ 

On the bottom left of the front of XIAO ESP32S3, there is a separate "WiFi/BT Antenna Connector". In order to get better WiFi/Bluetooth signal, you need to take out the antenna inside the package and install it on the connector.

There is a little trick to the installation of the antenna, if you press down hard on it directly, you will find it very difficult to press and your fingers will hurt! The correct way to install the antenna is to put one side of the antenna connector into the connector block first, then press down a little on the other side, and the antenna will be installed.

Installation of expansion boards (for Sense) ​ 

Installing the expansion board is very simple, you just need to align the connector on the expansion board with the B2B connector on the XIAO ESP32S3, press it hard and hear a "click", the installation is complete.

We now have a fully XIAO ESP32S3 Sense-compatible powerful camera, the OV5640, on our shelves — the auto-focus (AF) version with a heat sink . If you purchase it, you can replace the camera to use it.

Get One Now 🖱️ 

If you need to know the detailed parameter information of ov5640, you can refer to the following chart.

tip
 All the programs about cameras in the Wiki are compatible with both OV5640 and OV2640 cameras.

Prepare the microSD card ​ 

XIAO ESP32S3 Sense supports microSD cards up to 32GB , so if you are ready to buy a microSD card for XIAO, please refer to this specification. And format the microSD card to FAT32 format before using the microSD card.

After formatting, you can insert the microSD card into the microSD card slot. Please note the direction of insertion, the side with the gold finger should face inward.

Camera slot circuit design for expansion boards ​ 

The XIAO ESP32S3 Sense card slot occupies 14 GPIOs of the ESP32-S3, and the pin details of the occupancy are shown in the table below.

ESP32-S3 GPIO Camera ESP32-S3 GPIO Camera GPIO10 XMCLK GPIO11 DVP_Y8 GPIO12 DVP_Y7 GPIO13 DVP_PCLK GPIO14 DVP_Y6 GPIO15 DVP_Y2 GPIO16 DVP_Y5 GPIO17 DVP_Y3 GPIO18 DVP_Y4 GPIO38 DVP_VSYNC GPIO39 CAM_SCL GPIO40 CAM_SDA GPIO47 DVP_HREF GPIO48 DVP_Y9 

Turn on the PSRAM option ​ 

The PSRAM of ESP32 refers to the external PSRAM (Pseudo Static Random Access Memory) on the ESP32 chip, which provides additional memory space to increase the available memory of the ESP32 system. In the ESP32 system, PSRAM has the following main uses:

Extending the available RAM: The built-in RAM of ESP32 is limited, especially for some applications that need a lot of memory, such as image processing, audio processing, etc., the built-in RAM may not be enough. By using PSRAM, the available RAM of ESP32 can be extended to meet the needs of these applications.

Accelerated memory access: Since PSRAM is external memory, the access speed is slower than the internal RAM, however it can be used as a cache or temporary memory to accelerate memory access and data processing.

Storage buffers: For applications that require large buffers, such as network buffers, audio buffers, etc., PSRAM can provide enough storage space to avoid out-of-memory situations.

For the content of this tutorial, you need to turn on the PSRAM function of the Arduino IDE to ensure that the camera works properly.

Camera Library Overview ​ 

Before we start, we recommend you to read this chapter to understand the common camera functions. So that you can use these functions to complete your own project development or be able to read the program more easily.

Part I: esp_camera.h ​ 

Configuration structure for camera initialization.

The following is an example of the configuration, just fill in according to the actual pin situation.

static camera_config_t camera_example_config = { 
 . pin_pwdn = PWDN_GPIO_NUM , 
 . pin_reset = RESET_GPIO_NUM , 
 . pin_xclk = XCLK_GPIO_NUM , 
 . pin_sccb_sda = SIOD_GPIO_NUM , 
 . pin_sccb_scl = SIOC_GPIO_NUM , 
 . pin_d7 = Y9_GPIO_NUM , 
 . pin_d6 = Y8_GPIO_NUM , 
 . pin_d5 = Y7_GPIO_NUM , 
 . pin_d4 = Y6_GPIO_NUM , 
 . pin_d3 = Y5_GPIO_NUM , 
 . pin_d2 = Y4_GPIO_NUM , 
 . pin_d1 = Y3_GPIO_NUM , 
 . pin_d0 = Y2_GPIO_NUM , 
 . pin_vsync = VSYNC_GPIO_NUM , 
 . pin_href = HREF_GPIO_NUM , 
 . pin_pclk = PCLK_GPIO_NUM , 

. xclk_freq_hz = 20000000 , // The clock frequency of the image sensor 
 . fb_location = CAMERA_FB_IN_PSRAM ; // Set the frame buffer storage location 
 . pixel_format = PIXFORMAT_JPEG , // The pixel format of the image: PIXFORMAT_ + YUV422|GRAYSCALE|RGB565|JPEG 
 . frame_size = FRAMESIZE_UXGA , // The resolution size of the image: FRAMESIZE_ + QVGA|CIF|VGA|SVGA|XGA|SXGA|UXGA 
 . jpeg_quality = 12 , // The quality of the JPEG image, ranging from 0 to 63. 
 . fb_count = 2 , // The number of frame buffers to use. 
 . grab_mode = CAMERA_GRAB_WHEN_EMPTY // The image capture mode. 
 } ; 

Initialize the camera driver.

After configuring camera_example_config in the above format, we need to use this function to initialize the camera driver.

esp_err_t esp_camera_init ( const camera_config_t * config ) ; 

Input Parameters : Camera configuration parameters

Output : ESP_OK on success

note
 Currently this function can only be called once and there is no way to de-initialize this module.

Obtain pointer to a frame buffer.

camera_fb_t * esp_camera_fb_get ( ) ; 

Data structure of camera frame buffer:

typedef struct { 
 uint8_t * buf ; /*!< Pointer to the pixel data */ 
 size_t len ; /*!< Length of the buffer in bytes */ 
 size_t width ; /*!< Width of the buffer in pixels */ 
 size_t height ; /*!< Height of the buffer in pixels */ 
 pixformat_t format ; /*!< Format of the pixel data */ 
 struct timeval timestamp ; /*!< Timestamp since boot of the first DMA buffer of the frame */ 
 } camera_fb_t ; 

Return the frame buffer to be reused again.

void esp_camera_fb_return ( camera_fb_t * fb ) ; 

Input Parameters : Pointer to the frame buffer

Get a pointer to the image sensor control structure.

sensor_t * esp_camera_sensor_get ( ) ; 

Output : pointer to the sensor

Save camera settings to non-volatile-storage (NVS).

esp_err_t esp_camera_save_to_nvs ( const char * key ) ; 

Input Parameters : A unique nvs key name for the camera settings

Load camera settings from non-volatile-storage (NVS).

esp_err_t esp_camera_load_from_nvs ( const char * key ) ; 

Input Parameters : A unique nvs key name for the camera settings

Part II: img_converters.h ​ 

Convert image buffer to JPEG.

bool fmt2jpg_cb ( uint8_t * src , size_t src_len , uint16_t width , uint16_t height , pixformat_t format , uint8_t quality , jpg_out_cb cb , void * arg ) ; 

Input Parameters :

src : Source buffer in RGB565, RGB888, YUYV or GRAYSCALE format

src_len : Length in bytes of the source buffer

width : Width in pixels of the source image

height : Height in pixels of the source image

format : Format of the source image

quality : JPEG quality of the resulting image

cp : Callback to be called to write the bytes of the output JPEG

arg : Pointer to be passed to the callback

Output : true on success

Convert camera frame buffer to JPEG.

bool frame2jpg_cb ( camera_fb_t * fb , uint8_t quality , jpg_out_cb cb , void * arg ) ; 

Input Parameters :

fb : Source camera frame buffer

quality : JPEG quality of the resulting image

cp : Callback to be called to write the bytes of the output JPEG

arg : Pointer to be passed to the callback

Output : true on success

Convert image buffer to JPEG buffer.

bool fmt2jpg ( uint8_t * src , size_t src_len , uint16_t width , uint16_t height , pixformat_t format , uint8_t quality , uint8_t * * out , size_t * out_len ) ; 

Input Parameters :

src : Source buffer in RGB565, RGB888, YUYV or GRAYSCALE format

src_len : Length in bytes of the source buffer

width : Width in pixels of the source image

height : Height in pixels of the source image

format : Format of the source image

quality : JPEG quality of the resulting image

out : Pointer to be populated with the address of the resulting buffer. You MUST free the pointer once you are done with it.

out_len : Pointer to be populated with the length of the output buffer

Output : true on success

Convert camera frame buffer to JPEG buffer.

bool frame2jpg ( camera_fb_t * fb , uint8_t quality , uint8_t * * out , size_t * out_len ) ; 

Input Parameters :

fb : Source camera frame buffer

quality : JPEG quality of the resulting image

out : Pointer to be populated with the address of the resulting buffer

out_len : Pointer to be populated with the length of the output buffer

Output : true on success

Convert image buffer to BMP buffer.

bool fmt2bmp ( uint8_t * src , size_t src_len , uint16_t width , uint16_t height , pixformat_t format , uint8_t * * out , size_t * out_len ) ; 

Input Parameters :

src : Source buffer in RGB565, RGB888, YUYV or GRAYSCALE format

src_len : Length in bytes of the source buffer

width : Width in pixels of the source image

height : Height in pixels of the source image

format : Format of the source image

quality : JPEG quality of the resulting image

out : Pointer to be populated with the address of the resulting buffer.

out_len : Pointer to be populated with the length of the output buffer

Output : true on success

Convert camera frame buffer to BMP buffer.

bool frame2bmp ( camera_fb_t * fb , uint8_t * * out , size_t * out_len ) ; 

Input Parameters :

fb : Source camera frame buffer

quality : JPEG quality of the resulting image

cp : Callback to be called to write the bytes of the output JPEG

arg : Pointer to be passed to the callback

Output : true on success

Part III: app_httpd.cpp ​ 

note
 This part of the library introduction is based on the Create a video preservation terminal -- Based WebServer section. This library is mainly used to perform image acquisition and face recognition functions for the web server. It is not directly included in the onboard package of ESP.

Face recognition function.

static int run_face_recognition ( fb_data_t * fb , std :: list < dl :: detect :: result_t > * results ) 

Input Parameters : 

fb : a pointer to a struct representing a frame buffer containing image data.

results : a pointer to a list of detected face results.

Handles HTTP requests for BMP image files.

static esp_err_t bmp_handler ( httpd_req_t * req ) 

Input Parameters : a pointer to a struct representing the HTTP request.

Encodes JPEG image data in a streaming fashion.

static size_t jpg_encode_stream ( void * arg , size_t index , const void * data , size_t len ) 

Input Parameters : 

arg : a pointer to a user-defined argument that is passed to the function.

index : an index value indicating the current position within the image data.

data : a pointer to a buffer containing the image data to be encoded.

len : the length of the data buffer.

Handles HTTP requests for capturing and streaming images from camera.

static esp_err_t capture_handler ( httpd_req_t * req ) 

Input Parameters : a pointer to a struct representing the HTTP request.

Handles HTTP requests for streaming video from a camera.

static esp_err_t stream_handler ( httpd_req_t * req ) 

Input Parameters : a pointer to a struct representing the HTTP request.

Initializes and starts a camera server that captures and streams video over HTTP.

void startCameraServer ( ) 

Taking photos with the camera ​ 

Next we start with the most basic usage of the camera, for example, we will first use the camera to complete the image acquisition. The first project we will use the microSD card, the main task of this program is to get the camera footage every minute and then save the footage to the microSD card.

Before you start, do what I did and install the microSD card and the camera.

You can find the complete program code and the required dependency files below this link.

Download the Code 

Here is the Arduino program for this project.

# include "esp_camera.h" 
 # include "FS.h" 
 # include "SD.h" 
 # include "SPI.h" 

# define CAMERA_MODEL_XIAO_ESP32S3 // Has PSRAM 

# include "camera_pins.h" 

unsigned long lastCaptureTime = 0 ; // Last shooting time 
 int imageCount = 1 ; // File Counter 
 bool camera_sign = false ; // Check camera status 
 bool sd_sign = false ; // Check sd status 

// Save pictures to SD card 
 void photo_save ( const char * fileName ) { 
 // Take a photo 
 camera_fb_t * fb = esp_camera_fb_get ( ) ; 
 if ( ! fb ) { 
 Serial . println ( "Failed to get camera frame buffer" ) ; 
 return ; 
 } 
 // Save photo to file 
 writeFile ( SD , fileName , fb -> buf , fb -> len ) ; 

// Release image buffer 
 esp_camera_fb_return ( fb ) ; 

Serial . println ( "Photo saved to file" ) ; 
 } 

// SD card write file 
 void writeFile ( fs :: FS & fs , const char * path , uint8_t * data , size_t len ) { 
 Serial . printf ( "Writing file: %s\r\n" , path ) ; 

File file = fs . open ( path , FILE_WRITE ) ; 
 if ( ! file ) { 
 Serial . println ( "Failed to open file for writing" ) ; 
 return ; 
 } 
 if ( file . write ( data , len ) == len ) { 
 Serial . println ( "File written" ) ; 
 } else { 
 Serial . println ( "Write failed" ) ; 
 } 
 file . close ( ) ; 
 } 

void setup ( ) { 
 Serial . begin ( 115200 ) ; 
 while ( ! Serial ) ; // When the serial monitor is turned on, the program starts to execute 

camera_config_t config ; 
 config . ledc_channel = LEDC_CHANNEL_0 ; 
 config . ledc_timer = LEDC_TIMER_0 ; 
 config . pin_d0 = Y2_GPIO_NUM ; 
 config . pin_d1 = Y3_GPIO_NUM ; 
 config . pin_d2 = Y4_GPIO_NUM ; 
 config . pin_d3 = Y5_GPIO_NUM ; 
 config . pin_d4 = Y6_GPIO_NUM ; 
 config . pin_d5 = Y7_GPIO_NUM ; 
 config . pin_d6 = Y8_GPIO_NUM ; 
 config . pin_d7 = Y9_GPIO_NUM ; 
 config . pin_xclk = XCLK_GPIO_NUM ; 
 config . pin_pclk = PCLK_GPIO_NUM ; 
 config . pin_vsync = VSYNC_GPIO_NUM ; 
 config . pin_href = HREF_GPIO_NUM ; 
 config . pin_sscb_sda = SIOD_GPIO_NUM ; 
 config . pin_sscb_scl = SIOC_GPIO_NUM ; 
 config . pin_pwdn = PWDN_GPIO_NUM ; 
 config . pin_reset = RESET_GPIO_NUM ; 
 config . xclk_freq_hz = 20000000 ; 
 config . frame_size = FRAMESIZE_UXGA ; 
 config . pixel_format = PIXFORMAT_JPEG ; // for streaming 
 config . grab_mode = CAMERA_GRAB_WHEN_EMPTY ; 
 config . fb_location = CAMERA_FB_IN_PSRAM ; 
 config . jpeg_quality = 12 ; 
 config . fb_count = 1 ; 

// if PSRAM IC present, init with UXGA resolution and higher JPEG quality 
 // for larger pre-allocated frame buffer. 
 if ( config . pixel_format == PIXFORMAT_JPEG ) { 
 if ( psramFound ( ) ) { 
 config . jpeg_quality = 10 ; 
 config . fb_count = 2 ; 
 config . grab_mode = CAMERA_GRAB_LATEST ; 
 } else { 
 // Limit the frame size when PSRAM is not available 
 config . frame_size = FRAMESIZE_SVGA ; 
 config . fb_location = CAMERA_FB_IN_DRAM ; 
 } 
 } else { 
 // Best option for face detection/recognition 
 config . frame_size = FRAMESIZE_240X240 ; 
 # if CONFIG_IDF_TARGET_ESP32S3 
 config . fb_count = 2 ; 
 # endif 
 } 

// camera init 
 esp_err_t err = esp_camera_init ( & config ) ; 
 if ( err != ESP_OK ) { 
 Serial . printf ( "Camera init failed with error 0x%x" , err ) ; 
 return ; 
 } 

camera_sign = true ; // Camera initialization check passes 

// Initialize SD card 
 if ( ! SD . begin ( 21 ) ) { 
 Serial . println ( "Card Mount Failed" ) ; 
 return ; 
 } 
 uint8_t cardType = SD . cardType ( ) ; 

// Determine if the type of SD card is available 
 if ( cardType == CARD_NONE ) { 
 Serial . println ( "No SD card attached" ) ; 
 return ; 
 } 

Serial . print ( "SD Card Type: " ) ; 
 if ( cardType == CARD_MMC ) { 
 Serial . println ( "MMC" ) ; 
 } else if ( cardType == CARD_SD ) { 
 Serial . println ( "SDSC" ) ; 
 } else if ( cardType == CARD_SDHC ) { 
 Serial . println ( "SDHC" ) ; 
 } else { 
 Serial . println ( "UNKNOWN" ) ; 
 } 

sd_sign = true ; // sd initialization check passes 

Serial . println ( "Photos will begin in one minute, please be ready." ) ; 
 } 

void loop ( ) { 
 // Camera & SD available, start taking pictures 
 if ( camera_sign && sd_sign ) { 
 // Get the current time 
 unsigned long now = millis ( ) ; 

//If it has been more than 1 minute since the last shot, take a picture and save it to the SD card 
 if ( ( now - lastCaptureTime ) >= 60000 ) { 
 char filename [ 32 ] ; 
 sprintf ( filename , "/image%d.jpg" , imageCount ) ; 
 photo_save ( filename ) ; 
 Serial . printf ( "Saved picture: %s\r\n" , filename ) ; 
 Serial . println ( "Photos will begin in one minute, please be ready." ) ; 
 imageCount ++ ; 
 lastCaptureTime = now ; 
 } 
 } 
 } 

note
 The compilation and upload of this program requires two other dependencies, please go to GitHub and download them in full.

Please upload the program for XIAO ESP32S3, after the program is uploaded successfully, please turn on the serial monitor, adjust the camera to face the object you want to shoot, wait for one minute, the shot will be saved to the SD card. Next, XIAO will take a photo every minute.

Remove the microSD card and with the help of the card reader, you can see the photos saved inside the card.

Program annotation ​ 

The program starts with the camera and SD card libraries we need to use, and the import of some pin dependency files we defined for the XIAO ESP32S3.

Then for easy reading, we define two functions one after another, one is the function photo_save() that saves the captured image to the SD card, and the other is the function writeFile() that writes the file.

// Save pictures to SD card 
 void photo_save ( const char * fileName ) { 
 // Take a photo 
 camera_fb_t * fb = esp_camera_fb_get ( ) ; 
 if ( ! fb ) { 
 Serial . println ( "Failed to get camera frame buffer" ) ; 
 return ; 
 } 
 // Save photo to file 
 writeFile ( SD , fileName , fb -> buf , fb -> len ) ; 

// Release image buffer 
 esp_camera_fb_return ( fb ) ; 

Serial . println ( "Photo saved to file" ) ; 
 } 

In the function that saves the image to the microSD card, two main tasks are accomplished. The first one is the acquisition of the picture and the second one is the call to the function that writes the file.

Getting the image can be done with esp_camera_fb_get() , the image information will be saved in the pointer fb , and then we can write the buf of fb to the SD card.

In the Setup() function, a large segment of the program is configuring the camera pins and camera initialization, we can just apply it directly by default. If you have requirements for the camera's pixels or quality, you can adjust the values inside according to the functions described in the Camera Library Overview chapter.

The last thing to do in the loop() function is to control the photos to be taken every minute and follow the incremental number as the file name suffix of the taken photos.

if ( camera_sign && sd_sign ) { 
 // Get the current time 
 unsigned long now = millis ( ) ; 

//If it has been more than 1 minute since the last shot, take a picture and save it to the SD card 
 if ( ( now - lastCaptureTime ) >= 60000 ) { 
 char filename [ 32 ] ; 
 sprintf ( filename , "/image%d.jpg" , imageCount ) ; 
 photo_save ( filename ) ; 
 Serial . printf ( "Saved picture：%s\n" , filename ) ; 
 Serial . println ( "Photos will begin in one minute, please be ready." ) ; 
 imageCount ++ ; 
 lastCaptureTime = now ; 
 } 
 } 

Before executing the loop() , we configure two flag checks camera_sign and sd_sign . This ensures that the task of taking and saving pictures must be run after the camera and SD card checks have been successfully executed in Setup() .

Project I: Making a handheld camera ​ 

Next, we use the above theoretical knowledge to create a super small photo artifact. The end result of this project is that the live camera feed is displayed on the Seeed Studio Round Display for XIAO, and when you lock the object you want to photograph, touch the screen and take a picture to record on the microSD card.

Preliminary Preparation ​ 

Before starting this project, you will need to prepare the following hardware in advance.

Seeed Studio XIAO ESP32S3 Sense Seeed Studio Round Display for XIAO 

Get One Now 🖱️ 
 Get One Now 🖱️ 

Since this project will use Round Display for XIAO, please read the contents of the Wiki environment configuration of the display expansion board , install the necessary libraries and configure the TFT environment before you run the routines of this project.

Since the XIAO EPS32S3 Sense is designed with three pull-up resistors R4~R6 conne
